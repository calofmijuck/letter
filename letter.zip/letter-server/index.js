const dotenv = require('dotenv');
const thecamp = require('the-camp-lib');

async function send() {
  dotenv.config();

  const id = 'sungchan1012@naver.com';
  const password = '1q2w3e4r!!';

  const name = '이성찬';
  const birth = '19981012';
  const enterDate = '20200514';
  const className = '예비군인/훈련병';
  const groupName = '육군';
  const unitName = '육군훈련소';

  const soldier = new thecamp.Soldier(
    name,
    birth,
    enterDate,
    className,
    groupName,
    unitName,
    thecamp.SoldierRelationship.FAN,
  );

  const cookies = await thecamp.login(id, password);
  await thecamp.addSoldier(cookies, soldier);
  const [trainee] = await thecamp.fetchSoldiers(cookies, soldier);

  const message = new thecamp.Message('Title', 'Content', trainee);

  await thecamp.sendMessage(cookies, trainee, message);
};

send();
