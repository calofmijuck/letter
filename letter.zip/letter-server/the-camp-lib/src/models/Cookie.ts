/**
 * 세션 식별을 위한 쿠키
 */
interface Cookie {
  iuid: string;
  token: string;
}

export { Cookie };
