pwd > asdf
pwd > asdf
