var s = require('fs').readFileSync('/dev/stdin').toString().trim();

console.log(s);

// s = s.replace(/'/g, '"');
console.log(JSON.parse(s));

