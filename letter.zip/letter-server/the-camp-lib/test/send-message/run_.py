from os import listdir, system
from os.path import getsize, isfile, join


letter_dir = "../../../letters/"
sent_dir = "../../../letters/sent/"

names = [f for f in listdir(letter_dir) if isfile(join(letter_dir, f))]

# print(names)

msgs = []

for e in names:
    msgs.append((getsize(letter_dir + e), e))

# print(msgs)

msgs.sort()

print(msgs)

sending = msgs[-9:]

for msg in sending:
    filename = msg[1]
    cmd = "nodejs index_.js < " + letter_dir + filename
    system(cmd)
    print("Executing: " + cmd)

